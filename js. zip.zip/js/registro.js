(function () {
  'use strict';
  const A = window.Auth, $ = (s) => document.querySelector(s);
  if (A.current()) { location.replace(A.ROLES[A.current().role].home); return; }
  if (!A.hasUsers()) { location.replace('login.html'); return; } // primero se crea el administrador

  $('#pw').addEventListener('input', () => {
    const v = $('#pw').value; let n = 0;
    if (v.length >= 8) n++; if (v.length >= 12) n++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) n++; if (/\d/.test(v)) n++; if (/[^A-Za-z0-9]/.test(v)) n++;
    const m = $('#meter'); m.style.width = (n * 20) + '%'; m.style.background = n <= 2 ? '#c62828' : n <= 3 ? '#e0a100' : '#2e7d32';
  });

  $('#f').addEventListener('submit', (e) => {
    e.preventDefault();
    const err = $('#err'); err.hidden = true;
    const bad = [];
    const need = (id) => { if (!$('#' + id).value.trim()) bad.push(id); };
    ['username', 'email', 'pw', 'pw2', 'name', 'tel', 'unidad'].forEach(need);
    document.querySelectorAll('.invalid').forEach((x) => x.classList.remove('invalid'));
    try {
      if (bad.length) { bad.forEach((id) => $('#' + id).closest('.field').classList.add('invalid')); $('#' + bad[0]).focus(); throw new Error('Completa los campos obligatorios (*)'); }
      if ($('#pw').value !== $('#pw2').value) { $('#pw2').closest('.field').classList.add('invalid'); throw new Error('Las contraseñas no coinciden'); }
      const dni = $('#dni').value.replace(/[\s-]/g, '');
      if (dni && !/^\d{13}$/.test(dni)) { $('#dni').closest('.field').classList.add('invalid'); throw new Error('El número de identidad debe tener 13 dígitos'); }
      if (!/^[\d\s+()-]{7,20}$/.test($('#tel').value.trim())) { $('#tel').closest('.field').classList.add('invalid'); throw new Error('Ingresa un teléfono válido'); }
      const u = A.createUser({
        role: 'USUARIO', name: $('#name').value, username: $('#username').value, email: $('#email').value, password: $('#pw').value,
        profile: { dni, telefono: $('#tel').value.trim(), unidad: $('#unidad').value.trim(), cargo: $('#cargo').value.trim() },
      });
      A.startSession(u); location.replace(A.ROLES.USUARIO.home);
    } catch (ex) { err.textContent = ex.message; err.hidden = false; err.scrollIntoView({ block: 'nearest' }); }
  });
})();
