(function () {
  'use strict';
  const A = window.Auth, $ = (s) => document.querySelector(s);
  const params = new URLSearchParams(location.search);

  /* Si ya hay sesión, ir directo a la página del rol */
  const me = A.current();
  if (me) { location.replace(A.ROLES[me.role].home); return; }

  /* Solo se acepta como destino un archivo .html del mismo directorio */
  const safeNext = () => {
    const n = params.get('next') || '';
    return /^[\w-]+\.html(\?[\w=&%.-]*)?$/.test(n) ? n : '';
  };
  const enter = (u) => {
    const next = safeNext();
    location.replace(next || A.ROLES[u.role].home);
  };

  /* ---------- Primer uso: crear administrador ---------- */
  if (!A.hasUsers()) {
    $('#f-login').hidden = true; $('#f-setup').hidden = false;
    $('#title').textContent = 'Configuración inicial';
    $('#subtitle').textContent = 'Crea la primera cuenta de administrador.';
    $('#f-setup').addEventListener('submit', (e) => {
      e.preventDefault();
      const err = $('#s-err'); err.hidden = true;
      try {
        if ($('#s-pw').value !== $('#s-pw2').value) throw new Error('Las contraseñas no coinciden');
        const u = A.createUser({ name: $('#s-name').value, username: $('#s-user').value, email: $('#s-email').value, password: $('#s-pw').value, role: 'ADMINISTRADOR' });
        A.startSession(u); location.replace(A.ROLES.ADMINISTRADOR.home);
      } catch (ex) { err.textContent = ex.message; err.hidden = false; }
    });
    return;
  }

  /* ---------- Selector de rol ---------- */
  const roles = $('#roles'), hint = $('#role-hint'), submit = $('#submit');
  A.ROLE_KEYS.forEach((k, i) => {
    const r = A.ROLES[k];
    roles.insertAdjacentHTML('beforeend', `
      <label class="role-tile"><input type="radio" name="role" value="${k}" ${k === 'USUARIO' ? 'checked' : ''}>
        <span>${A.icon(r.icon, 22)}${r.label}</span></label>`);
  });
  const HINTS = {
    ADMINISTRADOR: 'Acceso total a la página y gestión de usuarios. Solo personal autorizado.',
    DESARROLLADOR: 'Consulta de las solicitudes registradas. Solo personal autorizado: usa la contraseña que te entregó el administrador.',
    SUPERVISOR: 'Seguimiento de la etapa en la que se encuentra cada desarrollo. Solo personal autorizado: usa la contraseña que te entregó el administrador.',
    USUARIO: 'Acceso a los formatos de Solicitud de Requerimiento y Solicitud de Cambios.',
  };
  const role = () => (document.querySelector('input[name="role"]:checked') || {}).value;
  function sync() {
    const r = role();
    hint.textContent = HINTS[r];
    submit.textContent = 'Ingresar como ' + A.ROLES[r].label;
    $('#reg-link').hidden = r !== 'USUARIO';
    $('#err').hidden = true;
  }
  roles.addEventListener('change', sync); sync();

  $('#toggle').addEventListener('click', () => {
    const pw = $('#pw'), show = pw.type === 'password';
    pw.type = show ? 'text' : 'password'; $('#toggle').textContent = show ? 'Ocultar' : 'Ver';
  });

  $('#f-login').addEventListener('submit', (e) => {
    e.preventDefault();
    const err = $('#err'); err.hidden = true;
    const email = $('#email').value.trim(), pw = $('#pw').value;
    if (!email || !pw) { err.textContent = 'Ingresa tu correo y contraseña'; err.hidden = false; return; }
    try { enter(A.login(email, pw, role())); }
    catch (ex) { err.textContent = ex.message; err.hidden = false; $('#pw').value = ''; $('#pw').focus(); }
  });
})();
