(function () {
  'use strict';
  const U = window.UGI, A = window.Auth, $ = U.$, esc = U.esc;
  const me = A.current(), isAdmin = me.role === 'ADMINISTRADOR';
  const ownerName = (r) => { const o = r.owner && A.userById(r.owner); return o ? o.name : r.solicitante || '—'; };

  $('#app').innerHTML = `
    <div class="page-head"><h1>Solicitudes</h1>
      <p>${isAdmin ? 'Todas las solicitudes registradas.' : 'Consulta de las solicitudes registradas. Tu rol es de solo lectura.'}</p></div>
    <section class="panel">
      <div class="toolbar">
        <input type="search" id="q" placeholder="Buscar por código, título o solicitante…" aria-label="Buscar">
        <select id="ft" aria-label="Formato"><option value="">Todos los formatos</option>${Object.keys(U.TIPOS).map((k) => `<option value="${k}">${esc(U.TIPOS[k])}</option>`).join('')}</select>
        <select id="fe" aria-label="Etapa"><option value="">Todas las etapas</option>${U.ETAPAS.map((e) => `<option>${esc(e)}</option>`).join('')}</select>
        <span class="spacer"></span><span class="muted" id="count"></span>
      </div>
      <div class="tbl-wrap"><table class="tbl" id="t" hidden>
        <thead><tr><th>Formato</th><th>Código</th><th>Título / Sistema</th><th>Solicitante</th><th style="width:110px">Fecha</th><th>Etapa</th><th style="width:110px">Detalle</th></tr></thead>
        <tbody></tbody></table></div>
      <p class="empty" id="empty">No hay solicitudes para mostrar.</p>
    </section>`;

  function render() {
    const q = $('#q').value.trim().toLowerCase(), ft = $('#ft').value, fe = $('#fe').value;
    const list = U.list().filter((r) =>
      (!ft || r.tipo === ft) && (!fe || U.etapaOf(r) === fe) &&
      (!q || [r.codigo, r.titulo, r.solicitante, ownerName(r)].some((x) => String(x || '').toLowerCase().includes(q))));
    $('#t').hidden = !list.length; $('#empty').hidden = !!list.length;
    $('#count').textContent = list.length + (list.length === 1 ? ' solicitud' : ' solicitudes');
    $('#t tbody').innerHTML = list.map((r) => `<tr>
      <td><span class="badge ${esc(r.tipo)}">${esc(U.TIPOS[r.tipo] || r.tipo)}</span></td><td>${esc(r.codigo)}</td><td>${esc(r.titulo)}</td>
      <td>${esc(r.solicitante || ownerName(r))}</td><td>${U.fmtDate(r.fecha)}</td><td>${U.etapaPill(r)}</td>
      <td><a class="btn ghost sm" href="${U.PAGES[r.tipo] || '#'}?id=${encodeURIComponent(r.id)}">${A.icon('eye', 15)} ${isAdmin ? 'Abrir' : 'Ver'}</a></td></tr>`).join('');
  }
  ['input', 'change'].forEach((ev) => $('#app').addEventListener(ev, render));
  render();
})();
