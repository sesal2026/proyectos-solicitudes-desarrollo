(function () {
  'use strict';
  const U = window.UGI, A = window.Auth, $ = U.$, esc = U.esc;
  const recs = U.list(), users = A.users();
  const by = (f) => recs.filter(f).length;
  const ownerName = (r) => { const o = r.owner && A.userById(r.owner); return o ? o.name : r.solicitante || '—'; };

  const etapaRows = U.ETAPAS.map((e) => ({ e, n: by((r) => U.etapaOf(r) === e) }));
  const max = Math.max(1, ...etapaRows.map((x) => x.n));
  const latest = recs.slice().sort((a, b) => String(b.actualizado || b.creado).localeCompare(String(a.actualizado || a.creado))).slice(0, 6);
  const newUsers = users.slice().sort((a, b) => b.created.localeCompare(a.created)).slice(0, 5);

  $('#app').innerHTML = `
    <div class="page-head"><h1>Panel de administración</h1><p>Resumen general de solicitudes y usuarios.</p></div>

    <section class="sboxes">
      <a class="sbox navy" href="solicitudes.html"><span class="bgic">${A.icon('list', 56)}</span><span class="num">${recs.length}</span><span class="lab">Solicitudes registradas</span><span class="more">Ver solicitudes →</span></a>
      <a class="sbox green" href="etapas.html"><span class="bgic">${A.icon('layers', 56)}</span><span class="num">${by((r) => U.etapaOf(r) === 'Implementada')}</span><span class="lab">Implementadas</span><span class="more">Ver etapas →</span></a>
      <a class="sbox orange" href="etapas.html"><span class="bgic">${A.icon('activity', 56)}</span><span class="num">${by((r) => ['En análisis', 'En desarrollo', 'En pruebas QA'].includes(U.etapaOf(r)))}</span><span class="lab">En proceso</span><span class="more">Ver etapas →</span></a>
      <a class="sbox purple" href="usuarios.html"><span class="bgic">${A.icon('users', 56)}</span><span class="num">${users.filter((u) => u.active).length}</span><span class="lab">Usuarios activos</span><span class="more">Gestionar usuarios →</span></a>
    </section>

    <div class="cols-2">
      <section class="panel"><header><h2>Solicitudes por etapa</h2></header><div class="pbody">
        <div class="bars">${etapaRows.map((x) => `
          <div class="bar-row"><span>${esc(x.e)}</span><div class="bar-track"><div class="bar-fill" style="width:${(x.n / max) * 100}%"></div></div><b>${x.n}</b></div>`).join('')}
        </div>
        <p class="muted" style="margin:14px 0 0">Requerimientos: <b>${by((r) => r.tipo === 'requerimiento')}</b> · Cambios en ambientes: <b>${by((r) => r.tipo === 'cambios')}</b></p>
      </div></section>

      <section class="panel"><header><h2>Usuarios por rol</h2><span class="spacer"></span><a class="btn sm" href="usuarios.html">+ Crear usuario</a></header><div class="pbody">
        <div class="rolegrid">${A.ROLE_KEYS.map((k) => `
          <div class="rolebox"><b>${users.filter((u) => u.role === k).length}</b>${A.roleBadge(k)}</div>`).join('')}
        </div>
      </div></section>
    </div>

    <section class="panel"><header><h2>Últimas solicitudes</h2></header>
      ${latest.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Formato</th><th>Código</th><th>Título / Sistema</th><th>Solicitante</th><th>Etapa</th><th>Actualizada</th></tr></thead><tbody>
        ${latest.map((r) => `<tr><td><span class="badge ${esc(r.tipo)}">${esc(U.TIPOS[r.tipo] || r.tipo)}</span></td>
          <td><a href="${U.PAGES[r.tipo] || '#'}?id=${encodeURIComponent(r.id)}">${esc(r.codigo)}</a></td><td>${esc(r.titulo)}</td><td>${esc(ownerName(r))}</td>
          <td>${U.etapaPill(r)}</td><td>${U.fmtDate(r.actualizado || r.creado)}</td></tr>`).join('')}
      </tbody></table></div>` : '<p class="empty">Aún no hay solicitudes registradas en este navegador.</p>'}
    </section>

    <section class="panel"><header><h2>Usuarios recientes</h2></header>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Creado</th></tr></thead><tbody>
        ${newUsers.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${A.roleBadge(u.role)}</td><td>${U.fmtDate(u.created)}</td></tr>`).join('')}
      </tbody></table></div>
    </section>`;
})();
