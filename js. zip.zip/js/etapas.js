(function () {
  'use strict';
  const U = window.UGI, A = window.Auth, $ = U.$, esc = U.esc;
  const me = A.current(), isAdmin = me.role === 'ADMINISTRADOR';
  let filtro = '';

  $('#app').innerHTML = `
    <div class="page-head"><h1>Etapas de desarrollo</h1>
      <p>${isAdmin ? 'Seguimiento del avance de cada solicitud. Como administrador puedes cambiar la etapa.' : 'Etapa en la que se encuentra el desarrollo de cada solicitud.'}</p></div>
    <section class="panel">
      <div class="toolbar" id="chips"></div>
      <div class="toolbar"><input type="search" id="q" placeholder="Buscar por código, título o solicitante…" aria-label="Buscar"><span class="spacer"></span><span class="muted" id="count"></span></div>
      <div class="etapa-list" id="list"></div>
    </section>`;

  const ownerName = (r) => { const o = r.owner && A.userById(r.owner); return o ? o.name : r.solicitante || '—'; };

  function stepper(r) {
    const e = U.etapaOf(r);
    if (e === 'Rechazada') return '<div class="rejected"><strong>Solicitud rechazada.</strong> No continúa en el flujo de desarrollo.</div>';
    const idx = U.FLOW.indexOf(e);
    return '<ol class="stepper">' + U.FLOW.map((s, i) => `<li class="${i < idx || e === 'Implementada' && i <= idx ? 'done' : i === idx ? 'now' : ''}">${esc(s)}</li>`).join('') + '</ol>';
  }

  function render() {
    const all = U.list();
    $('#chips').innerHTML = `<button class="chip ${filtro === '' ? 'on' : ''}" data-f="">Todas<b>${all.length}</b></button>` +
      U.ETAPAS.map((e) => `<button class="chip ${filtro === e ? 'on' : ''}" data-f="${esc(e)}">${esc(e)}<b>${all.filter((r) => U.etapaOf(r) === e).length}</b></button>`).join('');
    const q = $('#q').value.trim().toLowerCase();
    const list = all.filter((r) => (!filtro || U.etapaOf(r) === filtro) && (!q || [r.codigo, r.titulo, r.solicitante, ownerName(r)].some((x) => String(x || '').toLowerCase().includes(q))));
    $('#count').textContent = list.length + (list.length === 1 ? ' solicitud' : ' solicitudes');
    $('#list').innerHTML = list.length ? list.map((r) => `
      <article class="etapa-card" data-id="${esc(r.id)}">
        <header><h3>${esc(r.codigo)} · ${esc(r.titulo)}</h3>${U.etapaPill(r)}
          <span class="meta">${esc(U.TIPOS[r.tipo] || r.tipo)} · Solicitante: ${esc(r.solicitante || ownerName(r))} · ${U.fmtDate(r.fecha)}</span></header>
        ${stepper(r)}
        <div class="foot">
          <span class="muted">Etapa actualizada: ${U.fmtDate(r.etapaAt || r.creado)}</span>
          ${isAdmin ? `<label>Cambiar etapa: <select data-etapa aria-label="Cambiar etapa">${U.ETAPAS.map((e) => `<option ${e === U.etapaOf(r) ? 'selected' : ''}>${esc(e)}</option>`).join('')}</select></label>` : ''}
        </div>
        ${(r.hist || []).length ? `<details><summary>Historial de etapas (${r.hist.length})</summary><ul>${r.hist.slice().reverse().map((h) => `<li>${esc(h.etapa)} · ${U.fmtDate(h.at)} · ${esc(h.by || '')}</li>`).join('')}</ul></details>` : ''}
      </article>`).join('') : '<p class="empty">No hay solicitudes en esta vista.</p>';
  }

  $('#chips').addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (b) { filtro = b.dataset.f; render(); } });
  $('#q').addEventListener('input', render);
  $('#list').addEventListener('change', (e) => {
    const sel = e.target.closest('[data-etapa]'); if (!sel || !isAdmin) return;
    const r = U.get(sel.closest('[data-id]').dataset.id); if (!r) return;
    const now = new Date().toISOString();
    r.hist = (r.hist || []).concat({ etapa: sel.value, at: now, by: me.name });
    r.etapa = sel.value; r.etapaAt = now; r.actualizado = now;
    if (U.upsert(r)) { U.toast('Etapa actualizada a «' + sel.value + '»', 'ok'); render(); }
  });
  render();
})();
