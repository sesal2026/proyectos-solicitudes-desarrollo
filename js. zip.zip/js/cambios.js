(function () {
  'use strict';
  const U = window.UGI, $ = U.$, $$ = U.$$;
  const form = $('#f');
  const params = new URLSearchParams(location.search);
  let recId = params.get('id') || null;
  const draftKey = () => 'cambios' + (recId ? '_' + recId : '');

  /* ---------- UI condicional ---------- */
  function sync() {
    const emer = form.clasificacion.value === 'Emergencia';
    $('#emerg-box').hidden = !emer;
    $('#emerg-box textarea').required = emer;

    const infra = $$('input[name="tipo[]"]').some((c) => c.checked && c.value === 'Infraestructura');
    $('#subtipo-box').hidden = !infra;
    if (!infra) $$('input[name="subtipo[]"]').forEach((c) => { c.checked = false; });
    U.autosize(form);
  }
  form.addEventListener('change', sync);

  /* ---------- Carga de datos ---------- */
  function load(data) {
    $$('tbody[data-dyn]').forEach((tb) => {
      const firstKey = $('[name]', $('template', tb).content).name.replace('[]', '');
      U.setRows(tb, Math.max(3, (data && data[firstKey] || []).length));
    });
    U.fill(form, data || {});
    if (!data || !data.fecha_solicitud) form.fecha_solicitud.value = U.today();
    if (!data || !data.codigo) form.codigo.value = U.nextCode('SCA', 'cambios');
    sync();
  }

  function init() {
    const draft = U.draftGet(draftKey());
    const rec = recId && U.get(recId);
    if (rec && !Auth.canOpen(rec)) { location.replace(Auth.ROLES[Auth.current().role].home); return; }
    if (draft && draft.data) { load(draft.data); U.toast('Se recuperó tu borrador'); }
    else if (rec) load(rec.data);
    else load(null);
  }

  /* ---------- Autoguardado de borrador ---------- */
  const saveDraft = U.debounce(() => {
    if (U.draftSet(draftKey(), { data: U.collect(form), at: Date.now() })) {
      const d = new Date();
      $('#status').textContent = 'Borrador guardado ' + d.toLocaleTimeString('es-HN', { hour: '2-digit', minute: '2-digit' });
    }
  }, 500);
  form.addEventListener('input', saveDraft);
  form.addEventListener('change', saveDraft);
  U.initDynTables(form, saveDraft);

  /* ---------- Validación específica ---------- */
  function extra() {
    const bad = [];
    if (!$$('input[name="tipo[]"]').some((c) => c.checked)) bad.push($('input[name="tipo[]"]'));
    if (!$('#subtipo-box').hidden && !$$('input[name="subtipo[]"]').some((c) => c.checked)) bad.push($('input[name="subtipo[]"]'));

    const rows = U.rows($('#t-proc'));
    const filled = rows.filter((r) => $('textarea', r).value.trim() || $('input', r).value.trim());
    if (!filled.length) bad.push($('textarea', rows[0]));
    filled.forEach((r) => {
      if (!$('textarea', r).value.trim()) bad.push($('textarea', r));
      if (!$('input', r).value.trim()) bad.push($('input', r));
    });
    return bad;
  }

  /* ---------- Acciones ---------- */
  $('#b-print').addEventListener('click', print);
  $('#b-print2').addEventListener('click', print);
  function print() {
    const old = document.title;
    document.title = (form.codigo.value || 'Solicitud de cambios').replace(/[^\w.-]+/g, '_');
    U.autosize(form); window.print(); document.title = old;
  }

  $('#b-json').addEventListener('click', () => {
    const d = U.collect(form);
    U.download((d.codigo || 'solicitud-cambios') + '.json', JSON.stringify({ tipo: 'cambios', data: d }, null, 2));
  });

  $('#b-clear').addEventListener('click', () => {
    if (!confirm('¿Limpiar todo el formulario? Se perderá lo que no hayas registrado.')) return;
    U.draftDel(draftKey()); recId = null; history.replaceState(null, '', 'cambios.html');
    $('#done').hidden = true; load(null); window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  $('#b-new').addEventListener('click', () => {
    U.draftDel(draftKey()); recId = null; history.replaceState(null, '', 'cambios.html');
    $('#done').hidden = true; load(null); $('#status').textContent = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!U.validate(form, extra)) return;
    const data = U.collect(form);
    const now = new Date().toISOString();
    const prev = recId && U.get(recId);
    const rec = {
      id: recId || U.uid(), tipo: 'cambios', titulo: data.nombre_cambio, codigo: data.codigo,
      fecha: data.fecha_solicitud, solicitante: data.solicitante, creado: prev ? prev.creado : now, actualizado: now,
      owner: prev && prev.owner ? prev.owner : Auth.current().id,
      etapa: prev && prev.etapa ? prev.etapa : 'Recibida', etapaAt: prev && prev.etapaAt ? prev.etapaAt : now, hist: prev && prev.hist ? prev.hist : [], data,
    };
    if (!U.upsert(rec)) return;
    U.draftDel(draftKey()); recId = rec.id;
    history.replaceState(null, '', 'cambios.html?id=' + rec.id);
    $('#done-msg').innerHTML = `<strong>${U.esc(rec.codigo)}</strong> · ${U.esc(rec.titulo)}<br>
      <small>Guardada en este navegador el ${U.fmtDate(now)}. Puedes imprimirla o descargarla desde el historial.</small>`;
    $('#done').hidden = false; $('#done').scrollIntoView({ behavior: 'smooth', block: 'center' });
    U.toast('Solicitud registrada', 'ok');
  });

  init();
  Auth.applyReadonly(form);
})();
