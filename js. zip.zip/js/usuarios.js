(function () {
  'use strict';
  const U = window.UGI, A = window.Auth, $ = U.$, esc = U.esc;
  const me = A.current();

  $('#app').innerHTML = `
    <div class="page-head"><h1>Usuarios</h1><span class="spacer"></span><button class="btn" id="b-new">+ Crear usuario</button>
      <p>Crea cuentas para el personal autorizado (Desarrollador, Supervisor, Administrador) y entrégales su contraseña. Los usuarios comunes también pueden registrarse solos.</p></div>
    <section class="panel">
      <div class="toolbar">
        <input type="search" id="q" placeholder="Buscar por nombre, usuario o correo…" aria-label="Buscar">
        <select id="fr" aria-label="Rol"><option value="">Todos los roles</option>${A.ROLE_KEYS.map((k) => `<option value="${k}">${esc(A.ROLES[k].label)}</option>`).join('')}</select>
        <span class="spacer"></span><span class="muted" id="count"></span>
      </div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Nombre</th><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Creado</th><th style="width:300px">Acciones</th></tr></thead><tbody id="tb"></tbody></table></div>
      <p class="empty" id="empty" hidden>No hay usuarios que coincidan.</p>
    </section>

    <dialog class="dlg" id="dlg-new">
      <form id="f-new" novalidate autocomplete="off">
        <h3>Crear usuario</h3>
        <label class="field"><span class="lbl">Rol</span>
          <select id="n-role">${A.ROLE_KEYS.map((k) => `<option value="${k}">${esc(A.ROLES[k].label)} — ${esc(A.ROLES[k].desc)}</option>`).join('')}</select></label>
        <label class="field"><span class="lbl">Nombre completo</span><input type="text" id="n-name" maxlength="120" required></label>
        <label class="field"><span class="lbl">Nombre de usuario</span><input type="text" id="n-user" maxlength="30" required></label>
        <label class="field"><span class="lbl">Correo electrónico</span><input type="email" id="n-email" required></label>
        <label class="field"><span class="lbl">Contraseña</span>
          <div class="pw-row"><input type="text" id="n-pw" autocomplete="off" required><button type="button" class="btn ghost" id="n-gen">Generar</button></div>
          <small class="muted">Mínimo 8 caracteres, con letras y números. Se mostrará una sola vez para que se la entregues.</small></label>
        <p class="form-err" id="n-err" role="alert" hidden></p>
        <div class="dlg-actions"><button type="button" class="btn ghost" id="n-cancel">Cancelar</button><button type="submit" class="btn">Crear usuario</button></div>
      </form>
    </dialog>

    <dialog class="dlg" id="dlg-cred">
      <div>
        <h3 id="c-title">Credenciales de acceso</h3>
        <p class="form-ok">Copia estos datos y entrégalos a la persona. <strong>La contraseña no se volverá a mostrar.</strong></p>
        <div class="cred-box" id="c-box"></div>
        <div class="dlg-actions"><button class="btn ghost" id="c-copy">Copiar</button><button class="btn" id="c-close">Listo</button></div>
      </div>
    </dialog>`;

  const open = (d) => (d.showModal ? d.showModal() : d.setAttribute('open', ''));
  const loginUrl = () => location.href.replace(/[^/]*$/, '') + 'login.html';

  function render() {
    const q = $('#q').value.trim().toLowerCase(), fr = $('#fr').value;
    const list = A.users().filter((u) => (!fr || u.role === fr) && (!q || [u.name, u.username, u.email].some((x) => String(x).toLowerCase().includes(q))))
      .sort((a, b) => A.ROLE_KEYS.indexOf(a.role) - A.ROLE_KEYS.indexOf(b.role) || a.name.localeCompare(b.name));
    $('#count').textContent = list.length + (list.length === 1 ? ' usuario' : ' usuarios');
    $('#empty').hidden = !!list.length;
    $('#tb').innerHTML = list.map((u) => {
      const self = u.id === me.id;
      return `<tr data-id="${esc(u.id)}">
        <td><b>${esc(u.name)}</b>${self ? ' <span class="muted">(tú)</span>' : ''}${u.profile && u.profile.unidad ? `<br><small class="muted">${esc(u.profile.unidad)}</small>` : ''}</td>
        <td>${esc(u.username)}</td><td>${esc(u.email)}</td>
        <td>${self ? A.roleBadge(u.role) : `<select data-role aria-label="Rol de ${esc(u.name)}">${A.ROLE_KEYS.map((k) => `<option value="${k}" ${k === u.role ? 'selected' : ''}>${esc(A.ROLES[k].label)}</option>`).join('')}</select>`}</td>
        <td><span class="pill ${u.active ? 'on' : 'off'}">${u.active ? 'Activo' : 'Desactivado'}</span></td>
        <td>${U.fmtDate(u.created)}</td>
        <td><div class="row-actions">
          <button class="btn ghost sm" data-reset>${A.icon('key', 14)} Nueva contraseña</button>
          ${self ? '' : `<button class="btn ghost sm" data-toggle>${u.active ? 'Desactivar' : 'Activar'}</button><button class="btn danger sm" data-del>Eliminar</button>`}
        </div></td></tr>`;
    }).join('');
  }

  function showCreds(title, u, pw) {
    $('#c-title').textContent = title;
    $('#c-box').innerHTML = `<span>Nombre:</span> ${esc(u.name)}<br><span>Rol:</span> ${esc(A.ROLES[u.role].label)}<br><span>Correo:</span> ${esc(u.email)}<br><span>Contraseña:</span> ${esc(pw)}<br><span>Página:</span> ${esc(loginUrl())}`;
    open($('#dlg-cred'));
  }

  /* ---------- Crear ---------- */
  $('#b-new').addEventListener('click', () => { $('#f-new').reset(); $('#n-err').hidden = true; $('#n-pw').value = A.genPassword(); open($('#dlg-new')); });
  $('#n-cancel').addEventListener('click', () => $('#dlg-new').close());
  $('#n-gen').addEventListener('click', () => { $('#n-pw').value = A.genPassword(); });
  $('#f-new').addEventListener('submit', (e) => {
    e.preventDefault();
    const err = $('#n-err'); err.hidden = true;
    try {
      const pw = $('#n-pw').value;
      const u = A.createUser({ role: $('#n-role').value, name: $('#n-name').value, username: $('#n-user').value, email: $('#n-email').value, password: pw, createdBy: me.id });
      $('#dlg-new').close(); render(); showCreds('Usuario creado', u, pw);
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
  });

  /* ---------- Acciones por fila ---------- */
  $('#tb').addEventListener('click', (e) => {
    const tr = e.target.closest('tr'); if (!tr) return;
    const u = A.userById(tr.dataset.id); if (!u) return;
    if (e.target.closest('[data-reset]')) {
      if (!confirm(`¿Generar una nueva contraseña para ${u.name}? La anterior dejará de funcionar.`)) return;
      const pw = A.genPassword(); A.setPassword(u.id, pw); showCreds('Nueva contraseña', u, pw);
    } else if (e.target.closest('[data-toggle]')) {
      if (u.active && u.role === 'ADMINISTRADOR' && A.activeAdmins().length <= 1) { U.toast('Debe quedar al menos un administrador activo', 'error'); return; }
      A.updateUser(u.id, { active: !u.active }); render(); U.toast(u.active ? 'Usuario desactivado' : 'Usuario activado', 'ok');
    } else if (e.target.closest('[data-del]')) {
      if (u.role === 'ADMINISTRADOR' && u.active && A.activeAdmins().length <= 1) { U.toast('Debe quedar al menos un administrador activo', 'error'); return; }
      if (confirm(`¿Eliminar la cuenta de ${u.name}? Sus solicitudes registradas se conservan.`)) { A.deleteUser(u.id); render(); U.toast('Usuario eliminado'); }
    }
  });
  $('#tb').addEventListener('change', (e) => {
    const sel = e.target.closest('[data-role]'); if (!sel) return;
    const u = A.userById(sel.closest('tr').dataset.id);
    if (u.role === 'ADMINISTRADOR' && u.active && sel.value !== 'ADMINISTRADOR' && A.activeAdmins().length <= 1) { sel.value = u.role; U.toast('Debe quedar al menos un administrador activo', 'error'); return; }
    A.updateUser(u.id, { role: sel.value }); render(); U.toast('Rol actualizado a ' + A.ROLES[sel.value].label, 'ok');
  });
  ['input', 'change'].forEach((ev) => { $('#q').addEventListener(ev, render); $('#fr').addEventListener(ev, render); });

  /* ---------- Credenciales ---------- */
  $('#c-close').addEventListener('click', () => $('#dlg-cred').close());
  $('#c-copy').addEventListener('click', () => {
    const txt = $('#c-box').innerText;
    const done = () => U.toast('Copiado al portapapeles', 'ok');
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(txt).then(done, () => U.toast('No se pudo copiar; selecciona el texto manualmente', 'error'));
    else { const r = document.createRange(); r.selectNodeContents($('#c-box')); const s = getSelection(); s.removeAllRanges(); s.addRange(r); try { document.execCommand('copy'); done(); } catch (er) { U.toast('Selecciona el texto y cópialo manualmente', 'error'); } }
  });
  render();
})();
